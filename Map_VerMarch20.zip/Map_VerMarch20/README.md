This repository is part of my blog[ maps-on-blackboard](http://maps-on-blackboard.com) for article [Rotate and pinch osm map with geojson data](http://maps-on-blackboard.com/articles/rotate-and-pinch-osm-map-with-geojson-data/)

map1.html from this repository is used in the article.

#usage

```
git clone https://github.com/maps-on-blackboard/rotate-and-pinch-osm-map-with-geojson-data
cd rotate-and-pinch-osm-map-with-geojson-data
npm install 
npm run start
```

and you can check the maps in your browser
```
http://0.0.0.0:8180/map[n].html
e.g. http://0.0.0.0:8180/map1.html

```

